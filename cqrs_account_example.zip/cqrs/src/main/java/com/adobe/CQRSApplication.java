package com.adobe;

import org.axonframework.eventsourcing.EventCountSnapshotTriggerDefinition;
import org.axonframework.eventsourcing.SnapshotTriggerDefinition;
import org.axonframework.eventsourcing.Snapshotter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
//docker run -d --rm --name axonserver -p 8024:8024 -p 8124:8124 axoniq/axonserver
@SpringBootApplication
public class CQRSApplication {

	public static void main(String[] args) {
		SpringApplication.run(CQRSApplication.class, args);
	}

	
	@Bean
    public SnapshotTriggerDefinition accountAggregateSnapshotTriggerDefinition(Snapshotter snapshotter,
                                                                             @Value("${axon.aggregate.order.snapshot-threshold:5}") int threshold) {
        return new EventCountSnapshotTriggerDefinition(snapshotter, threshold);
    }

}
