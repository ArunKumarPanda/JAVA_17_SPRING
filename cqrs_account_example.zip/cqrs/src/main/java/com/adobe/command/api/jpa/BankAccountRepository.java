package com.adobe.command.api.jpa;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adobe.command.api.entity.BankAccount;


public interface BankAccountRepository extends JpaRepository<BankAccount, UUID> {
}