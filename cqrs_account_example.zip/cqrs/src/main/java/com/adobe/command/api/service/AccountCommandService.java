package com.adobe.command.api.service;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adobe.command.api.commands.CreateAccountCommand;
import com.adobe.command.api.commands.CreditMoneyCommand;
import com.adobe.command.api.commands.DebitMoneyCommand;
import com.adobe.command.api.dto.AccountCreationDTO;
import com.adobe.command.api.dto.MoneyAmountDTO;
import com.adobe.command.api.entity.BankAccount;

import static com.adobe.command.api.service.ServiceUtils.formatUuid;

@Service
public class AccountCommandService {

	@Autowired
	private  CommandGateway commandGateway;

    public CompletableFuture<BankAccount> createAccount(AccountCreationDTO creationDTO) {
        return this.commandGateway.send(new CreateAccountCommand(
                UUID.randomUUID(),
                creationDTO.getInitialBalance(),
                creationDTO.getOwner()
        ));
    }

    public CompletableFuture<String> creditMoneyToAccount(String accountId,
                                                          MoneyAmountDTO moneyCreditDTO) {
        return this.commandGateway.send(new CreditMoneyCommand(
                formatUuid(accountId),
                moneyCreditDTO.getAmount()
        ));
    }

    public CompletableFuture<String> debitMoneyFromAccount(String accountId,
                                                           MoneyAmountDTO moneyDebitDTO) {
        return this.commandGateway.send(new DebitMoneyCommand(
                formatUuid(accountId),
                moneyDebitDTO.getAmount()
        ));
    }
}
