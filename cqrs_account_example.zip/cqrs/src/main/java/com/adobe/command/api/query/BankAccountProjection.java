package com.adobe.command.api.query;

import org.axonframework.queryhandling.QueryHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.adobe.command.api.entity.BankAccount;
import com.adobe.command.api.jpa.BankAccountRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BankAccountProjection {

	@Autowired
    private BankAccountRepository repository;


    @QueryHandler
    public BankAccount handle(FindBankAccountQuery query) {
        log.debug("Handling FindBankAccountQuery query: {}", query);
        return this.repository.findById(query.getAccountId()).orElse(null);
    }
}