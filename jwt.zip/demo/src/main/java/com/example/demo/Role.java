package com.example.demo;

public enum Role {
 USER,
  ADMIN
}