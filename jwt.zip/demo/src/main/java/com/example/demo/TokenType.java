package com.example.demo;

public enum TokenType {
	 BEARER
}
